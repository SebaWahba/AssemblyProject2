#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
using namespace std;

#define DRAM_SIZE (64*1024*1024)
#define CACHE_SIZE (64*1024)

enum cacheResType {MISS=0, HIT=1};

/* Random number generator for randomized access in memGen3 */
unsigned int m_w = 0xABABAB55;
unsigned int m_z = 0x05080902;
unsigned int rand_()
{
    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    return (m_z << 16) + m_w;
}

/* Memory generators */
unsigned int memGen1() { static unsigned int addr=0; return (addr++)%(DRAM_SIZE); }
unsigned int memGen2() { static unsigned int addr=0; return rand_()%(24*1024); }
unsigned int memGen3() { return rand_()%(DRAM_SIZE); }
unsigned int memGen4() { static unsigned int addr=0; return (addr++)%(4*1024); }
unsigned int memGen5() { static unsigned int addr=0; return (addr++)%(1024*64); }
unsigned int memGen6() { static unsigned int addr=0; return (addr+=32)%(64*4*1024); }

/* CacheLine Struct with its different components (valid, tag and lastUsed)*/
struct CacheLine {
    bool valid;
    unsigned int tag;
    unsigned int lastUsed;
};

/* Cache Class */
class Cache {
private:
    int lineSize;
    int associativity;
    int numSets;
    unsigned int accessCounter;
    vector<vector<CacheLine>> sets;

public:
    Cache(int lineSize, int associativity) {
        this->lineSize = lineSize; //size of line which is variable in experiments
        this->associativity = associativity;  // number of ways in set associative cache
        this->numSets = CACHE_SIZE / (lineSize * associativity);
        this->accessCounter = 0;

        sets.resize(numSets, vector<CacheLine>(associativity));
        for (auto& set : sets) {
            for (auto& line : set) {
                line.valid = false; //makes all lines empty at first by making the flag false
                line.lastUsed = 0; //making the lastused counter equal to 0 such that the access times is indeed 0 at first
            }
        }
    }

    cacheResType access(unsigned int addr) {
        accessCounter++; //increment the number of access times

        int blockOffsetBits = __builtin_ctz(lineSize); //counts the number of bits dedicated to the offset
        int indexBits = __builtin_ctz(numSets); //number of bits allocated to the index
        unsigned int index = (addr >> blockOffsetBits) & ((1 << indexBits) - 1); //shift and bitmask to extract the index
        unsigned int tag = addr >> (blockOffsetBits + indexBits); //shift and add to extract the tag

        // Search for hit
        for (auto& line : sets[index]) {
            if (line.valid && line.tag == tag) {
                line.lastUsed = accessCounter;
                return HIT;
            }
        }

        // Miss: find LRU or empty line
        int lruIndex = 0;
        unsigned int minTime = sets[index][0].lastUsed;

        for (int i = 0; i < associativity; ++i) {
            if (!sets[index][i].valid) {
                lruIndex = i;
                break;
            }
            if (sets[index][i].lastUsed < minTime) {
                minTime = sets[index][i].lastUsed;
                lruIndex = i;
            }
        }

        sets[index][lruIndex].valid = true; //after access it makes the valid true
        sets[index][lruIndex].tag = tag; //makes the tag equal to the current tag
        sets[index][lruIndex].lastUsed = accessCounter; //makes the lastused equal to the access counter

        return MISS;
    }
};

/* Test Config */
#define NUM_ITERATIONS 1000000
void runTestCases() {
    cout << "=== Running Functional Test Cases ===\n";

    // Test 1: Direct-mapped
    {
        cout << "\nTest 1: Direct-mapped, same address reuse\n";
        Cache cache(64, 1); // Direct-mapped, 1024 sets
        vector<unsigned int> addrs = {0x0000, 0x0040, 0x0000, 0x10000, 0x0000};
        vector<string> expected = {"MISS", "MISS", "HIT", "MISS", "MISS"};
        for (int i = 0; i < addrs.size(); ++i) {
            cacheResType res = cache.access(addrs[i]);
            cout << "Access 0x" << hex << addrs[i] << ": Expected " << expected[i]
                 << ", Got " << (res == HIT ? "HIT" : "MISS") << "\n";
        }
    }

    // Test 2: 2-way associativity
    {
        cout << "\nTest 2: 2-way associativity\n";
        Cache cache(64, 2); // 512 sets
        unsigned int base = 0x0000;
        vector<unsigned int> addrs = {
            base,
            base + 64 * 512, // different tag, same index
            base,            // should still be there → HIT
            base + 64 * 512  // HIT again
        };
        vector<string> expected = {"MISS", "MISS", "HIT", "HIT"};

        for (int i = 0; i < addrs.size(); ++i) {
            cacheResType res = cache.access(addrs[i]);
            cout << "Access 0x" << hex << addrs[i] << ": Expected " << expected[i]
                 << ", Got " << (res == HIT ? "HIT" : "MISS") << "\n";
        }
    }
    //fully associative
    {
        cout << "\nTest: Fully Associative Cache\n";
        Cache cache(64, 1024); // Fully associative (1 set, 1024 ways)

        vector<unsigned int> addrs;
        for (int i = 0; i < 5; ++i)
            addrs.push_back(i * 64);  // Different blocks

        // First round: all MISSes
        for (int i = 0; i < addrs.size(); ++i) {
            cacheResType res = cache.access(addrs[i]);
            cout << "Access 0x" << hex << addrs[i] << ": Expected MISS, Got "
                 << (res == HIT ? "HIT" : "MISS") << "\n";
        }

        // Second round: all HITs (same addresses)
        for (int i = 0; i < addrs.size(); ++i) {
            cacheResType res = cache.access(addrs[i]);
            cout << "Access 0x" << hex << addrs[i] << ": Expected HIT, Got "
                 << (res == HIT ? "HIT" : "MISS") << "\n";
        }
    }
    //four way set associative
    {
        cout << "\nTest: 4-Way Set-Associative Cache (No Eviction)\n";
        Cache cache(64, 4); // 4-way set-associative

        unsigned int base = 0x0000;
        vector<unsigned int> addrs = {
            base,                // MISS
            base + 0x4000,       // MISS → same set, new tag
            base + 0x8000,       // MISS → same set, new tag
            base + 0xC000,       // MISS → same set, new tag
            base,                // HIT
            base + 0x4000        // HIT
        };

        vector<string> expected = {"MISS", "MISS", "MISS", "MISS", "HIT", "HIT"};

        for (int i = 0; i < addrs.size(); ++i) {
            cacheResType res = cache.access(addrs[i]);
            cout << "Access 0x" << hex << addrs[i] << ": Expected " << expected[i]
                 << ", Got " << (res == HIT ? "HIT" : "MISS") << "\n";
        }
    }
}
int main() {
    runTestCases();
    vector<unsigned int(*)(void)> generators = {memGen1, memGen2, memGen3, memGen4, memGen5, memGen6};
    const char* msg[2] = {"Miss", "Hit"};

    for (int g = 0; g < generators.size(); ++g) {
        cout << "=== memGen" << (g + 1) << " ===\n";

        // Experiment 1: Vary line size, fixed 4 sets
        cout << "Experiment 1 (Vary line size, fixed sets = 4):"<<endl;
        for (int lineSize : {16, 32, 64, 128}) {
            int ways = CACHE_SIZE / (lineSize * 4); // So sets = 4
            Cache cache(lineSize, ways);

            int hits = 0;
            for (int i = 0; i < NUM_ITERATIONS; ++i) {
                unsigned int addr = generators[g]();
                if (cache.access(addr) == HIT) hits++;
            }

            float hitRatio = hits * 100.0 / NUM_ITERATIONS;
            cout << "Line Size: " << setw(3) << lineSize << " bytes, Ways: " << setw(2) << ways
                 << " -> Hit Ratio: " << fixed << setprecision(2) << hitRatio << "%\n";
        }

        // Experiment 2: Vary associativity, fixed line size = 64
        cout << "Experiment 2 (Vary ways, fixed line size = 64):"<<endl;
        for (int ways : {1, 2, 4, 8, 16}) {
            Cache cache(64, ways);
            int hits = 0;

            for (int i = 0; i < NUM_ITERATIONS; ++i) {
                unsigned int addr = generators[g]();
                if (cache.access(addr) == HIT) hits++;
            }

            float hitRatio = hits * 100.0 / NUM_ITERATIONS;
            cout << "Ways: " << setw(2) << ways << " -> Hit Ratio: " << fixed << setprecision(2) << hitRatio << "%\n";
        }

        cout << "\n===========================\n";
    }

    return 0;
}
